pub mod gauss_kronrod;
pub mod gauss_legendre;
pub mod newton_cotes;
