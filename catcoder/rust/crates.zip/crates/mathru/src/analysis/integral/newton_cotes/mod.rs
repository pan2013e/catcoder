mod closedfixedintervaliterator;
mod newton_cotes;

pub use closedfixedintervaliterator::ClosedFixedIntervalIterator;
pub use newton_cotes::NewtonCotes;
