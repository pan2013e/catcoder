// ! This module provides different algorithms to solve initial value problems.
pub mod explicit;
pub mod implicit;
