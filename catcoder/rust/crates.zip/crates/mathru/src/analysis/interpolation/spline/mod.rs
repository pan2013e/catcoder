//! Spline interpolation
mod cubic_spline;

pub use cubic_spline::{CubicSpline, CubicSplineConstraint};
