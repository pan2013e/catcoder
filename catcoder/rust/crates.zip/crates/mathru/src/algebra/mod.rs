//! Abstract and linear algebra.

#[macro_use]
pub mod linear;
pub mod abstr;
