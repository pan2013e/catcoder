pub mod diagonal;
pub mod general;
